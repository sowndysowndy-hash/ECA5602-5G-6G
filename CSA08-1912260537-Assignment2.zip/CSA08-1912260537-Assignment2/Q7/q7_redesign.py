# Q7 C-F - Redesign: bottom-up loop that keeps only the last two values
import time

def ways_naive(n, counter):
    counter["calls"] += 1
    if n <= 1:
        return 1
    counter["adds"] += 1
    return ways_naive(n - 1, counter) + ways_naive(n - 2, counter)

def ways_loop(n):
    prev, cur = 1, 1                       # ways(0), ways(1)
    adds = 0
    for _ in range(n - 1):
        prev, cur = cur, prev + cur
        adds += 1
    return cur, adds

print("Prediction: loop does n-1 additions; naive does (calls-1)/2 = ways(n)-1 additions")
print(f"\n{'n':>4}{'naive calls':>13}{'naive adds':>12}{'naive s':>10}"
      f"{'loop adds':>11}{'loop s':>12}{'speed-up':>12}{'equal':>7}")
for n in (10, 20, 25, 30):
    c = {"calls": 0, "adds": 0}
    t = time.perf_counter(); a = ways_naive(n, c); tn = time.perf_counter() - t
    t = time.perf_counter()
    for _ in range(1000): b, adds = ways_loop(n)
    tl = (time.perf_counter() - t) / 1000
    print(f"{n:>4}{c['calls']:>13,}{c['adds']:>12,}{tn:>10.5f}{adds:>11}"
          f"{tl:>12.8f}{tn / tl:>12,.0f}{str(a == b):>7}")

print("\nObjective check at large n (loop only; the naive version cannot finish):")
print(f"{'n':>8}{'additions':>11}{'time ms':>10}{'digits':>9}")
for n in (1000, 10000, 100000):
    t = time.perf_counter(); v, adds = ways_loop(n); dt = (time.perf_counter() - t) * 1000
    digits = len(str(v)) if n <= 10000 else v.bit_length() * 0.30103 // 1
    print(f"{n:>8}{adds:>11}{dt:>10.3f}{digits:>9.0f}")
