# Q7 A - Diagnose the bottleneck of the plain recursive ways_naive(n) from Q6
from collections import Counter
calls_per_arg = Counter()

def ways_naive(n):
    calls_per_arg[n] += 1
    if n <= 1:
        return 1
    return ways_naive(n - 1) + ways_naive(n - 2)

N = 20
result = ways_naive(N)
total = sum(calls_per_arg.values())
print(f"ways({N}) = {result}")
distinct = len(calls_per_arg)
print(f"total calls = {total:,} | different arguments = {distinct}"
      f" | repeated calls = {total - distinct:,}")
print(f"share of calls that repeat earlier work = {100 * (total - distinct) / total:.2f} %")
print("\nargument k : number of times ways(k) was called (n = 20)")
for k in sorted(calls_per_arg, reverse=True):
    print(f"  k = {k:>2} : {calls_per_arg[k]:>6,}")

print("\nGrowth of the call count (ratio of consecutive n):")
def count_calls(n):
    c = 0
    def f(m):
        nonlocal c
        c += 1
        if m <= 1:
            return 1
        return f(m - 1) + f(m - 2)
    f(n)
    return c
prev = None
for n in range(10, 31, 5):
    c = count_calls(n)
    print(f"  n = {n:>2}: calls = {c:>9,}" + (f"   x{c / prev:.2f} for 5 more steps" if prev else ""))
    prev = c
