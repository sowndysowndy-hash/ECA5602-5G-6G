import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
plt.rcParams["font.family"] = "serif"
ns = list(range(1, 31))
def ways(n):
    a, b = 1, 1
    for _ in range(n - 1): a, b = b, a + b
    return b
naive = [2 * ways(n) - 1 for n in ns]
loop = [max(n - 1, 0) for n in ns]
fig, ax = plt.subplots(figsize=(6.4, 3.6), dpi=200)
ax.semilogy(ns, naive, "o-", color="#b3261e", ms=3.5, label="Original: plain recursion (calls)")
ax.semilogy(ns, [x + 1 for x in loop], "s-", color="#1b6b3a", ms=3.5, label="Redesign: loop (iterations + 1)")
ax.set_xlabel("number of steps n"); ax.set_ylabel("operations (log scale)")
ax.set_title("Growth of work: original vs redesigned")
ax.grid(True, which="both", alpha=.3); ax.legend(frameon=False)
fig.tight_layout(); fig.savefig("outputs/q7_graph.png")
