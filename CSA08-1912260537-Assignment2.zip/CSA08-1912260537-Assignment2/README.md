# CSA08 - Python Programming - Assignment 2 (CO2)

- **Name:** P Sowndarya
- **Register number:** 1912260537
- **Python version:** 3.12.3 (Q1 uses `match-case`, which needs Python 3.10+)
- **Libraries:** standard library only, except `Q7/q7_plot.py` (matplotlib, see `requirements.txt`)

Install the optional library with `pip install -r requirements.txt`.
Run every program from inside its question folder, for example `cd Q1` and then `python q1_main.py`.
Each program prints raw counts and timings; its output is saved in `outputs/` as `.txt` and `.png`.
Timings differ from computer to computer; counts do not.

| Task | Program | Result |
|---|---|---|
| Q1 | q1_main.py | 8 households predicted correctly at 100/101/200/201 units; buggy ifs gave two subsidies to 202 of 1,204 households; if-elif matched the fixed ifs for all |
| Q1 | q1_design.py | nested if and combined conditions agree for all 1,204 households; combined chosen |
| Q1 | q1_alt.py | match-case and table lookup agree; table search grows O(k), bisect O(log k) |
| Q2 | q2_main.py | while and for loops with break, continue, pass, loop-else; wrong counter placement locks the account after only 2 real attempts |
| Q2 | q2_changed.py | two extra attempts after a correct security answer (cases A-D) |
| Q2 | q2_alt.py | recursion gives the same results; RecursionError at 2000 attempts, the loop has none |
| Q3 | q3_main.py | matches the expected output of the assignment |
| Q3 | q3_extra.py | six predicted inputs match; receipt format TN 09 AB 1234; immutability and slicing demos |
| Q3 | q3_alt.py | regex and slicing disagree on 0 of 22,000 strings; non-ASCII letters/digits found as an edge case |
| Q4 | q4_main.py (run 3 times) | same text True, length 3048890; join about 1.7x faster than += on average |
| Q4 | q4_measure.py | += vs join vs f-string at 1,000 / 10,000 / 200,000 lines |
| Q4 | q4_alt.py | join vs StringIO vs file: time and peak memory (writes statement.txt) |
| Q5 | q5_main.py | default-list bug explained with `__defaults__`; three independent customers; global/nonlocal demos |
| Q5 | q5_alt.py | explicit list and closure designs, O(1) per item |
| Q6 | q6_a.py | naive 121393 with 242785 calls; memo 121393 with 26 calls |
| Q6 | q6_b.py | n=1-6 verified, call tree for n=5, call counts for n=10/20/25/30 |
| Q6 | q6_c.py | RecursionError at n=1000; raised limit and loop both work |
| Q7 | q7_diagnose.py | 99.90% of calls repeat earlier work (n=20) |
| Q7 | q7_redesign.py | loop redesign: 29 additions instead of 2,692,537 calls at n=30 |
| Q7 | q7_plot.py | draws the growth graph into `outputs/` |
