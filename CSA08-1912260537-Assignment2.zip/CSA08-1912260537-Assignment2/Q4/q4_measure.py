# Q4 - three implementations, three sizes, average of 3 runs
import time

def build_plus(parts):                      # (a) repeated +=
    text = ""
    for p in parts:
        text += p + ";"
    return text

def build_join(parts):                      # (b) list of parts + join
    return ";".join(parts) + ";"

def build_fstring(parts):                   # (c) f-string for each line
    text = ""
    for p in parts:
        text += f"{p};"
    return text

def build_plus_alias(parts):                # += when a second reference exists
    text = ""
    for p in parts:
        keep = text                         # extra reference defeats CPython's in-place trick
        text += p + ";"
    return text

def timed(fn, parts, runs=3):
    best = []
    for _ in range(runs):
        t = time.perf_counter(); fn(parts); best.append(time.perf_counter() - t)
    return sum(best) / runs

print(f"{'lines':>8}{'+= (a) s':>12}{'join (b) s':>12}{'f-string (c) s':>16}{'(a)/(b)':>9}")
for n in (1000, 10000, 200000):
    parts = [f"Item{i}:Rs{i % 50}" for i in range(n)]
    ta, tb, tc = (timed(f, parts) for f in (build_plus, build_join, build_fstring))
    assert build_plus(parts) == build_join(parts) == build_fstring(parts)
    print(f"{n:>8}{ta:>12.5f}{tb:>12.5f}{tc:>16.5f}{ta / tb:>9.1f}")

print("\n+= with a second reference alive (copy on every step):")
print(f"{'lines':>8}{'time s':>10}{'chars copied':>15}")
prev = None
for n in (5000, 10000, 20000, 40000):
    parts = [f"Item{i}:Rs{i % 50}" for i in range(n)]
    t = timed(build_plus_alias, parts, runs=1)
    copied = sum(len(parts[i]) + 1 for i in range(n)) * n // 2
    print(f"{n:>8}{t:>10.4f}{copied:>15,}" + (f"   x{t / prev:.1f} for 2x lines" if prev else ""))
    prev = t
