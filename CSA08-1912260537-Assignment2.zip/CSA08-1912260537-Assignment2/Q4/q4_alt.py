# Q4 - Alternative concept: io.StringIO and writing line by line to a file
import io, time, tracemalloc, os

n = 200_000
parts = [f"Item{i}:Rs{i % 50}" for i in range(n)]

def via_join():
    return ";".join(parts) + ";"

def via_stringio():
    buf = io.StringIO()
    for p in parts:
        buf.write(p); buf.write(";")
    return buf.getvalue()

def via_file():
    with open("statement.txt", "w") as f:
        for p in parts:
            f.write(p + ";")
    return os.path.getsize("statement.txt")

print(f"{'method':12}{'time s':>9}{'peak extra MB':>15}")
for name, fn in (("join", via_join), ("StringIO", via_stringio), ("file", via_file)):
    t = time.perf_counter(); fn(); dt = time.perf_counter() - t
    tracemalloc.start(); fn(); peak = tracemalloc.get_traced_memory()[1]; tracemalloc.stop()
    print(f"{name:12}{dt:>9.4f}{peak / 1e6:>15.2f}")
print("same text (join vs StringIO):", via_join() == via_stringio())
print("file size equals text length:", via_file() == len(via_join()))
