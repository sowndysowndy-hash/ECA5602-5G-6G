# Q2 - Changed condition: two extra attempts after a correct security answer
OTP = "482913"

def verify_extended(entries, security_ok):
    feed = iter(entries)
    limit, attempts, extended = 3, 0, False
    while attempts < limit:                # limit can change, so while is natural
        entry = next(feed).strip()
        if entry == "":
            continue
        attempts += 1
        if entry == OTP:
            print(f"   attempt {attempts}: correct OTP")
            break
        print(f"   attempt {attempts}: wrong OTP")
        if attempts == limit and not extended:
            print("   security question asked ->", "correct, +2 attempts" if security_ok else "wrong")
            if security_ok:
                limit += 2
                extended = True
    else:
        print(f"   LOCKED FOR 30 MINUTES after {attempts} attempts")
        return "LOCKED", attempts
    return "VERIFIED", attempts

print("A: 3 wrong, security ok, 4th wrong, 5th correct")
print(" ->", verify_extended(["1", "2", "3", "4", "482913"], True))
print("B: 3 wrong, security answer wrong")
print(" ->", verify_extended(["1", "2", "3", "4", "5"], False))
print("C: 5 wrong with security ok")
print(" ->", verify_extended(["1", "2", "3", "4", "5", "6"], True))
print("D: blank entries never counted, correct on 2nd real attempt")
print(" ->", verify_extended(["", "1", "", "482913"], True))
