# Q2 - Alternative concept: recursive attempt loop and its stack cost
import sys, timeit
OTP = "482913"

def verify_rec(feed, attempt=1, limit=3):
    entry = next(feed).strip()
    if entry == "":
        return verify_rec(feed, attempt, limit)        # blank: same attempt number
    if entry == OTP:
        return "VERIFIED", attempt
    if attempt == limit:
        return "LOCKED", attempt
    return verify_rec(feed, attempt + 1, limit)

def verify_loop(feed, limit=3):
    attempts = 0
    while attempts < limit:
        entry = next(feed).strip()
        if entry == "":
            continue
        attempts += 1
        if entry == OTP:
            return "VERIFIED", attempts
    return "LOCKED", attempts

print("recursion limit:", sys.getrecursionlimit())
print("recursive S1:", verify_rec(iter(["", "111111", "482913"])))
print("recursive S2:", verify_rec(iter(["000000", "", "123456", "999999"])))
print("loop      S2:", verify_loop(iter(["000000", "", "123456", "999999"])))

wrong = lambda: iter(lambda: "000000", None)           # endless wrong entries
print(f"\n{'attempts a':>10}{'loop':>14}{'recursion':>26}{'loop us':>10}{'rec us':>9}")
for a in (10, 100, 500, 900, 2000):
    r1 = verify_loop(wrong(), a)
    try:
        r2 = verify_rec(wrong(), 1, a)
        rec = str(r2)
    except RecursionError:
        rec = "RecursionError"
    t1 = timeit.timeit(lambda: verify_loop(wrong(), a), number=200) / 200 * 1e6
    try:
        t2 = f"{timeit.timeit(lambda: verify_rec(wrong(), 1, a), number=200) / 200 * 1e6:.1f}"
    except RecursionError:
        t2 = "-"
    print(f"{a:>10}{str(r1):>14}{rec:>26}{t1:>10.1f}{t2:>9}")
