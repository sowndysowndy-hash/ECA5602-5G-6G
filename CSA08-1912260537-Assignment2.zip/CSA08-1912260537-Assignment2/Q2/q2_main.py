# Q2 - OTP verification at a bank kiosk: while loop, for loop, break/continue/pass/else
OTP = "482913"
MAX = 3

def verify_while(entries):
    feed = iter(entries)
    attempts = 0
    while attempts < MAX:
        entry = next(feed).strip()
        if entry == "":
            print("   (blank entry ignored)")
            continue                       # blank: skip, counter NOT updated
        attempts += 1                      # counter updated after the blank check
        if entry == OTP:
            print(f"   attempt {attempts}: correct OTP")
            break                          # success: leave the loop, skip else
        elif attempts < MAX:
            print(f"   attempt {attempts}: wrong OTP, {MAX - attempts} left")
        else:
            pass                           # last wrong attempt: loop-else reports it
    else:
        print(f"   attempt {attempts}: wrong OTP -> ACCOUNT LOCKED FOR 30 MINUTES")
        return "LOCKED", attempts
    return "VERIFIED", attempts

def verify_for(entries):
    feed = iter(entries)
    for attempt in range(1, MAX + 1):      # the for loop itself counts the attempts
        while True:                        # inner loop skips blank entries
            entry = next(feed).strip()
            if entry == "":
                print("   (blank entry ignored)")
                continue
            break
        if entry == OTP:
            print(f"   attempt {attempt}: correct OTP")
            break
        elif attempt < MAX:
            print(f"   attempt {attempt}: wrong OTP, {MAX - attempt} left")
        else:
            pass
    else:
        print(f"   attempt {attempt}: wrong OTP -> ACCOUNT LOCKED FOR 30 MINUTES")
        return "LOCKED", attempt
    return "VERIFIED", attempt

def verify_while_buggy(entries):           # counter updated in the WRONG place
    feed = iter(entries)
    attempts = 0
    while attempts < MAX:
        attempts += 1                      # BUG: blank entries are counted
        entry = next(feed).strip()
        if entry == "":
            continue
        if entry == OTP:
            return "VERIFIED", attempts
    return "LOCKED", attempts

scenarios = {
    "S1 blank, wrong, correct":      ["", "111111", "482913"],
    "S2 wrong,blank,wrong,blank,wrong": ["000000", "", "123456", "  ", "999999"],
    "S3 correct at first try":       ["482913"],
}
for name, entries in scenarios.items():
    print(f"\n{name}")
    print(" while ->", verify_while(entries))
    print(" for   ->", verify_for(entries))

print("\nBug demonstration: counter before blank check, entries = blank, blank, wrong, correct")
print(" buggy while ->", verify_while_buggy(["", "", "111111", "482913"]))
print(" fixed while ->", verify_while(["", "", "111111", "482913"]))
