# Q5 - Alternatives: caller passes the list, or a closure keeps it
import sys, timeit

def add_explicit(item, order):             # the caller always supplies the list
    order.append(item)
    return order

def make_order():                          # closure keeps the list private
    order = []
    def add(item):
        order.append(item)
        return order
    return add

def add_none(item, order=None):            # default None (main design)
    if order is None:
        order = []
    order.append(item)
    return order

a1, a2 = make_order(), make_order()
a1("Tea"); a1("Vada"); a2("Dosa")
print("closure customers:", a1("Coffee"), a2("Tea"))
print("closure cells    :", [c.cell_contents for c in a1.__closure__])
print("explicit         :", add_explicit("Tea", []), add_explicit("Vada", []))

n = 200_000
G = globals()
t_none = timeit.timeit("for i in range(1000): add_none(i, o)",
                       setup="o=[]", globals=G, number=n // 1000)
t_expl = timeit.timeit("for i in range(1000): add_explicit(i, o)",
                       setup="o=[]", globals=G, number=n // 1000)
t_clos = timeit.timeit("for i in range(1000): add(i)",
                       setup="add=make_order()", globals=G, number=n // 1000)
print(f"\n{n} adds to ONE order  none-default {t_none/n*1e9:.0f} ns"
      f" | explicit {t_expl/n*1e9:.0f} ns | closure {t_clos/n*1e9:.0f} ns per item")

o = []
for i in range(100): o.append(i)
add = make_order()
for i in range(100): add(i)
print("\nsize of a 100-item order list   :", sys.getsizeof(o), "bytes")
extra = sys.getsizeof(add) + sys.getsizeof(add.__closure__[0])
print("extra for closure (function+cell):", extra, "bytes (constant per customer)")
