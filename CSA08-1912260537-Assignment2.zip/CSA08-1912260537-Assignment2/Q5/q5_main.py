# Q5 - Canteen order system: default-parameter bug, return values, scope
def add_item_buggy(item, order=[]):
    order.append(item)
    return order

def add_item(item, order=None):
    if order is None:
        order = []
    order.append(item)
    return order

print(add_item_buggy("Tea"), add_item_buggy("Vada"))
print(add_item("Tea"), add_item("Vada"))
print("defaults after the calls:", add_item_buggy.__defaults__)
print("defaults of fixed one   :", add_item.__defaults__)

PRICES = {"Tea": 10, "Vada": 12, "Dosa": 40, "Coffee": 15}

def bill(order, gst_rate=0.05, *, prices=PRICES):
    """Returns THREE values: subtotal, GST and total (packed as a tuple)."""
    subtotal = sum(prices[i] for i in order)
    gst = round(subtotal * gst_rate, 2)
    return subtotal, gst, round(subtotal + gst, 2)

print("\n--- three customers in sequence ---")
c1 = add_item("Tea");  add_item("Vada", c1)
c2 = add_item("Dosa")
c3 = add_item("Coffee"); add_item("Tea", c3); add_item("Dosa", order=c3)
for n, o in enumerate((c1, c2, c3), 1):
    sub, gst, total = bill(o)
    print(f"customer {n}: {o} subtotal={sub} GST={gst} total={total}")
print("independent:", c1 is not c2 is not c3, "| same call, other GST rate:", bill(c1, 0.12))
print("keyword order does not matter:", bill(gst_rate=0.18, order=["Tea"]))

print("\n--- local / global / nonlocal ---")
orders_served = 0                      # global name

def serve_wrong():
    try:
        orders_served += 1             # assignment makes it LOCAL -> error
    except UnboundLocalError as e:
        print("without global ->", type(e).__name__)

def serve_global():
    global orders_served
    orders_served += 1

def make_counter():
    count = 0                          # local to make_counter
    def next_token():
        nonlocal count                 # refers to the enclosing function's name
        count += 1
        return count
    return next_token

def local_demo():
    orders_served = 99                 # new local name, hides the global
    return orders_served

serve_wrong()
serve_global(); serve_global()
print("global after 2 calls  :", orders_served)
print("local_demo() returns  :", local_demo(), "| global still", orders_served)
token = make_counter()
print("nonlocal tokens       :", token(), token(), token())
