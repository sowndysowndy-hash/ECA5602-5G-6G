# Q6 - recursion limit, loop version and comparison at n = 1000
import sys, time
from functools import lru_cache

@lru_cache(maxsize=None)
def ways_memo(n):
    if n <= 1:
        return 1
    return ways_memo(n - 1) + ways_memo(n - 2)

def ways_naive(n):
    if n <= 1:
        return 1
    return ways_naive(n - 1) + ways_naive(n - 2)

def ways_loop(n):
    prev, cur = 1, 1                       # ways(0), ways(1)
    for _ in range(n - 1):
        prev, cur = cur, prev + cur
    return cur

print("recursion limit:", sys.getrecursionlimit())
try:
    ways_memo(1000)
except RecursionError as e:
    print("ways_memo(1000) ->", type(e).__name__ + ":", e)

ways_memo.cache_clear()
sys.setrecursionlimit(3000)
t = time.perf_counter(); m = ways_memo(1000); tm = time.perf_counter() - t
print("limit raised to 3000 -> memo works, digits:", len(str(m)), f"| {tm * 1e6:.0f} us")
sys.setrecursionlimit(1000)

t = time.perf_counter(); l = ways_loop(1000); tl = time.perf_counter() - t
print("loop version         -> digits:", len(str(l)), f"| {tl * 1e6:.0f} us (limit 1000, no error)")
print("memo == loop:", m == l)

t = time.perf_counter(); r = ways_naive(30); tn = time.perf_counter() - t
print(f"naive for n=30 takes {tn:.3f} s; for n=1000 it would need about "
      "1.4 x 10^209 calls (never finishes)")
print("ways(1000) starts with", str(l)[:12], "... and has", len(str(l)), "digits")
