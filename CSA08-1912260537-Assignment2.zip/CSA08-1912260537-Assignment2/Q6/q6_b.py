# Q6 - correctness table, call tree for n = 5 and call counts
from functools import lru_cache
calls = 0

def ways_naive(n):
    global calls
    calls += 1
    if n <= 1:
        return 1
    return ways_naive(n - 1) + ways_naive(n - 2)

@lru_cache(maxsize=None)
def ways_memo(n):
    global calls
    calls += 1
    if n <= 1:
        return 1
    return ways_memo(n - 1) + ways_memo(n - 2)

by_hand = {1: 1, 2: 2, 3: 3, 4: 5, 5: 8, 6: 13}
print("n  by hand  naive  memo")
for n, h in by_hand.items():
    ways_memo.cache_clear()
    print(f"{n}  {h:^7}  {ways_naive(n):^5}  {ways_memo(n):^4}")

print("\nCall tree for n = 5 (each line is one call):")
def tree(n, depth=0):
    print("  " * depth + f"ways({n})")
    if n <= 1:
        return 1
    return tree(n - 1, depth + 1) + tree(n - 2, depth + 1)
tree(5)

print("\nPrediction: calls_naive(n) = 2*ways(n) - 1 ; calls_memo(n) = n + 1")
print(f"{'n':>3}{'predicted naive':>17}{'naive calls':>13}{'predicted memo':>16}{'memo calls':>12}")
for n in (10, 20, 25, 30):
    calls = 0; w = ways_naive(n); cn = calls
    ways_memo.cache_clear(); calls = 0; ways_memo(n); cm = calls
    print(f"{n:>3}{2 * w - 1:>17,}{cn:>13,}{n + 1:>16}{cm:>12}")
