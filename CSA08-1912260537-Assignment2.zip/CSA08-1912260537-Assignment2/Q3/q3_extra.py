# Q3 - formatting function, six designed inputs, immutability and slicing
def normalise(text):
    return text.strip().replace(" ", "").replace("-", "").upper()

def is_valid(reg):
    if len(reg) not in (9, 10):
        return False
    return (reg[:2].isalpha() and reg[2:4].isdigit()
            and reg[4:-4].isalpha() and reg[-4:].isdigit())

def format_plate(reg):
    """Valid 'TN09AB1234' -> 'TN 09 AB 1234' (receipt format)."""
    if not is_valid(reg):
        return None
    return " ".join([reg[:2], reg[2:4], reg[4:-4], reg[-4:]])

tests = [  # (typed text, predicted verdict made before running)
    ("tn 09 ab 1234",  "VALID"),
    ("TN-09-AB-1234",  "VALID"),
    ("Tn09Ab1234",     "VALID"),
    ("  ka 01 m 0007 ", "VALID"),
    ("TN09ABC1234",    "INVALID"),    # 3 series letters
    ("TN 09 AB 123",   "INVALID"),    # only 3 digits at the end
]
print(f"{'typed':17}{'normalised':13}{'predicted':10}{'observed':9}{'receipt'}")
for raw, pred in tests:
    reg = normalise(raw)
    obs = "VALID" if is_valid(reg) else "INVALID"
    print(f"{raw!r:17}{reg:13}{pred:10}{obs:9}{format_plate(reg)}")

print("\n--- immutability ---")
s = "tn09ab1234"
print("id(s) before upper():", id(s))
t = s.upper()
print("s after s.upper()   :", s, "| t:", t, "| same object:", s is t)
try:
    s[0] = "T"
except TypeError as e:
    print("s[0] = 'T'  ->", type(e).__name__ + ":", e)

print("\n--- slicing ---")
for reg in ("KA01M0007", "TN09AB1234"):
    print(f"{reg} (len {len(reg)}): s[-4:] = {reg[-4:]!r}, s[4:-4] = {reg[4:-4]!r}")
