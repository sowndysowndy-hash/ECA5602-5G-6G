# Q3 - Alternative concept: regular expression validation
import re, random, timeit

PATTERN = re.compile(r"[A-Z]{2}[0-9]{2}[A-Z]{1,2}[0-9]{4}")

def valid_slice(reg):
    if len(reg) not in (9, 10):
        return False
    return (reg[:2].isalpha() and reg[2:4].isdigit()
            and reg[4:-4].isalpha() and reg[-4:].isdigit())

def valid_regex(reg):
    return PATTERN.fullmatch(reg) is not None

random.seed(1)
alphabet = "TNKAM019 -"
cases = ["".join(random.choice(alphabet) for _ in range(random.choice((9, 10)))) for _ in range(20000)]
cases = [c.replace(" ", "").replace("-", "").upper() for c in cases]
cases += ["TN09AB1234", "KA01M0007", "TN9AB1234", "TN221234AB"] * 500
diff = sum(valid_slice(c) != valid_regex(c) for c in cases)
print("strings compared:", len(cases), "| disagreements:", diff,
      "| valid found:", sum(map(valid_regex, cases)))

for bad in ("\u00c9\u00c909AB1234", "TN\u00b2\u00b2AB1234"):
    print(f"{bad}: slicing -> {valid_slice(bad)}, regex -> {valid_regex(bad)}")

n = 200000
samples = ["TN09AB1234", "KA01M0007", "TN9AB1234", "TN221234AB"]
t1 = timeit.timeit(lambda: [valid_slice(x) for x in samples], number=n // 4)
t2 = timeit.timeit(lambda: [valid_regex(x) for x in samples], number=n // 4)
print(f"\n{n} validations: slicing {t1:.3f} s ({t1/n*1e6:.2f} us each)"
      f" | regex {t2:.3f} s ({t2/n*1e6:.2f} us each)")
for L in (10, 1000, 100000):
    long_bad = "TN09AB" + "1" * (L - 6)
    a = timeit.timeit(lambda: valid_slice(long_bad), number=2000) / 2000 * 1e6
    b = timeit.timeit(lambda: valid_regex(long_bad), number=2000) / 2000 * 1e6
    print(f"length {L:>6}: slicing {a:8.2f} us | regex {b:8.2f} us")
