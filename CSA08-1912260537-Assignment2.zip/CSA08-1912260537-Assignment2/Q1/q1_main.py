# Q1 - State Electricity Subsidy Eligibility (three implementations compared)
# household = (id, units, has_ration_card, has_member_above_80)
households = [
    ("H1",  50, False, False),
    ("H2", 100, True,  False),
    ("H3", 101, True,  False),
    ("H4", 101, False, False),
    ("H5", 200, True,  False),
    ("H6", 201, True,  False),
    ("H7", 201, False, True),
    ("H8", 250, False, False),
]

# Predictions written BEFORE running any code
predicted = {"H1": "FULL", "H2": "FULL", "H3": "PARTIAL", "H4": "NONE",
             "H5": "PARTIAL", "H6": "NONE", "H7": "SENIOR", "H8": "NONE"}

def rule_buggy(units, ration, senior):          # separate ifs, upper bound only
    result = []
    if units <= 100:
        result.append("FULL")
    if units <= 200 and ration:                 # BUG: lower bound 101 missing
        result.append("PARTIAL")
    if units > 200 and senior:
        result.append("SENIOR")
    return result or ["NONE"]

def rule_separate(units, ration, senior):       # separate ifs, chained comparison
    result = []
    if units <= 100:
        result.append("FULL")
    if 101 <= units <= 200 and ration:
        result.append("PARTIAL")
    if units > 200 and senior:
        result.append("SENIOR")
    return result or ["NONE"]

def rule_elif(units, ration, senior):           # if-elif-else, exactly one result
    if units <= 100:
        return "FULL"
    elif 101 <= units <= 200 and ration:
        return "PARTIAL"
    elif units > 200 and senior:
        return "SENIOR"
    else:
        return "NONE"

print(f"{'ID':3}{'Units':>6} {'Ration':7}{'Age80':6}{'Predicted':10}"
      f"{'Buggy ifs':16}{'Fixed ifs':10}{'if-elif':8}{'OK'}")
for hid, u, r, s in households:
    b = "+".join(rule_buggy(u, r, s))
    f = "+".join(rule_separate(u, r, s))
    e = rule_elif(u, r, s)
    ok = (f == e == predicted[hid])
    print(f"{hid:3}{u:>6} {str(r):7}{str(s):6}{predicted[hid]:10}"
          f"{b:16}{f:10}{e:8}{'yes' if ok else 'NO'}")

# Exhaustive check over 0..300 units x 2 x 2 flags = 1204 households
total = two_results = mismatch = 0
for u in range(0, 301):
    for r in (False, True):
        for s in (False, True):
            total += 1
            if len(rule_buggy(u, r, s)) > 1:
                two_results += 1
            if "+".join(rule_separate(u, r, s)) != rule_elif(u, r, s):
                mismatch += 1
print("\nhouseholds tested           :", total)
print("buggy rule: two subsidies   :", two_results)
print("fixed ifs vs if-elif differ :", mismatch)
