# Q1 - Alternative concept: match-case and a lookup table of (upper limit, decision)
import sys, timeit, bisect, math

def rule_elif(units, ration, senior):
    if units <= 100: return "FULL"
    elif 101 <= units <= 200 and ration: return "PARTIAL"
    elif units > 200 and senior: return "SENIOR"
    else: return "NONE"

def rule_match(units, ration, senior):          # Python 3.10+
    match units:
        case u if u <= 100:
            return "FULL"
        case u if u <= 200 and ration:
            return "PARTIAL"
        case u if u > 200 and senior:
            return "SENIOR"
        case _:
            return "NONE"

SLABS = [(100, "FULL", None), (200, "PARTIAL", "ration"), (float("inf"), "SENIOR", "senior")]
def rule_table(units, ration, senior):
    flags = {"ration": ration, "senior": senior}
    for limit, decision, needs in SLABS:        # linear search, k comparisons worst case
        if units <= limit:
            return decision if needs is None or flags[needs] else "NONE"

same = all(rule_elif(u, r, s) == rule_match(u, r, s) == rule_table(u, r, s)
           for u in range(0, 301) for r in (False, True) for s in (False, True))
print("elif == match-case == table for 1204 households:", same)

def make_slabs(k):
    return [(10 * (i + 1), f"S{i}") for i in range(k)]

def look_loop(slabs, units):
    for limit, decision in slabs:
        if units <= limit:
            return decision
    return "TOP"

def look_loop_count(slabs, units):
    n = 0
    for limit, decision in slabs:
        n += 1
        if units <= limit:
            break
    return n

def look_bisect(slabs, limits, units):
    i = bisect.bisect_left(limits, units)
    return slabs[i][1] if i < len(slabs) else "TOP"

print(f"\n{'k':>6}{'comparisons(loop)':>19}{'comparisons(bisect)':>21}"
      f"{'loop us':>10}{'bisect us':>11}{'list bytes':>12}")
for k in (4, 40, 400, 4000):
    slabs = make_slabs(k); limits = [s[0] for s in slabs]
    worst = 10 * k + 5                           # beyond the last slab = worst case
    t1 = timeit.timeit(lambda: look_loop(slabs, worst), number=3000) / 3000 * 1e6
    t2 = timeit.timeit(lambda: look_bisect(slabs, limits, worst), number=3000) / 3000 * 1e6
    size = sys.getsizeof(slabs) + sum(sys.getsizeof(t) for t in slabs)
    print(f"{k:>6}{look_loop_count(slabs, worst):>19}"
          f"{math.ceil(math.log2(k + 1)):>21}{t1:>10.2f}{t2:>11.2f}{size:>12}")
