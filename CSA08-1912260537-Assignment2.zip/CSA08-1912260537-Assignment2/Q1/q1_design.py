# Q1 - Design decision: nested if  vs  combined Boolean conditions
def rule_nested(units, ration, senior):
    if units <= 100:
        return "FULL"
    else:
        if units <= 200:
            if ration:
                return "PARTIAL"
            else:
                return "NONE"
        else:
            if senior:
                return "SENIOR"
            else:
                return "NONE"

def rule_combined(units, ration, senior):
    if units <= 100:
        return "FULL"
    elif 101 <= units <= 200 and ration:
        return "PARTIAL"
    elif units > 200 and senior:
        return "SENIOR"
    else:
        return "NONE"

same = all(rule_nested(u, r, s) == rule_combined(u, r, s)
           for u in range(0, 301) for r in (False, True) for s in (False, True))
print("nested == combined for all 1204 households:", same)
